#' Title
#' @importFrom cowsay
#' @return
#' @export
#'
#' @examples
hello <- function() {
  cowsay::say("nope, don't do that", type = "warning")
}
